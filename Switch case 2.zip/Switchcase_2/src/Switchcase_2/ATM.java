package Switchcase_2;
import java.util.Scanner;
public class ATM {

	public static void main(String[] args) {
	Scanner S = new Scanner(System.in);
	System.out.println("Welcome to SBI ATM");
	System.out.println("Insert your SBI card");
	System.out.println("1. Cash withdrawal");
	System.out.println("2. Balance Inquiry");
	System.out.println("3. Mini Statement");
	System.out.println("4. PIN Change");
	System.out.println("5. Cash Desposit");
	System.out.print("Enter the option between 1 to 5 : ");
	int option = S.nextInt();
	S.nextLine();
	switch (option) {
	case 1:
        
	    System.out.print("Account Type Selection (Saving/Current/Checking/Credit) : ");
	    String type = S.nextLine();
	    System.out.print("Amount Entry (100/200/500/2000) : " );
	    int Amountentry = S.nextInt();
	    S.nextLine();
	    System.out.print("Receipt preference (Yes/NO) : ");
	    String Receipt = S.nextLine();
	break;
	case 2:
	    System.out.print("Account Type Selection (Saving/Current/Checking/Credit) : ");
	    String type1 = S.nextLine();
	    System.out.print("Display preference (View/Print) : ");
	    String display = S.nextLine();
	break;
	case 3:
	    System.out.print("Account Type Selection (Saving/Current/Checking/Credit) : ");
	    String type3 = S.nextLine();
	    System.out.print("you will get the print of last 5 transactions ");
	break;
	case 4:
		System.out.print("Current pin verification (Existing pin) : ");
		int oldpin = S.nextInt();
		System.out.print("Enter New pin (4 digit or 6 digit pin) : ");
		int newpin = S.nextInt();
		System.out.print("Re Enter the new pin : ");
		int newpin1 = S.nextInt();
		break;
	case 5:
	    System.out.print("Account Type Selection (Saving/Current/Checking/Credit) : ");
	    String type4 = S.nextLine();
	    S.nextLine();
	    System.out.println("Insert card");
	    System.out.println("Verify the amount");
	    System.out.println("Confirm");
	    System.out.print("Receipt preference (Yes/NO) : ");
	    String Receipt1 = S.nextLine();
	    System.out.println("Thank you");
	    break;
	default:
		System.out.print("Enter the valid input 1 to 5 ");
	}
	}

}
