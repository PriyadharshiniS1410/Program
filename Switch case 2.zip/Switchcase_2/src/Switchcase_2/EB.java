package Switchcase_2;
import java.util.Scanner;
public class EB {

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		System.out.println("---- TNEB Bill Calculator ---");
        System.out.println("1. Domestic (Household)");
        System.out.println("2. Commercial (Shop/Business/Office)");
        System.out.print("Select connection type (1 or 2): ");
        int connectionType = S.nextInt();
		System.out.print("Enter your unit : ");
		int units = S.nextInt();
		double billAmount=0;
		switch (connectionType) {
		case 1:
            int tariff = (units <= 500) ? 1 : 2;
            
            switch (tariff) {
                case 1: 
                    if (units <= 200) 
                    {
                        billAmount = 0; 
                    } 
                    else if (units <= 400) 
                    {
                        billAmount = (units - 200) * 4.95;
                    } 
                    else 
                    {
                        billAmount = (200 * 4.95) + ((units - 400) * 6.65);
                    }
                    break;
                    
                case 2: 
                    if (units <= 400) 
                    {
                        billAmount = (units - 100) * 4.95;
                    } 
                    else if (units <= 500) 
                    {
                        billAmount = (300 * 4.95) + ((units - 400) * 6.65);
                    } 
                    else if (units <= 600) 
                    {
                        billAmount = (300 * 4.95) + (100 * 6.65) + ((units - 500) * 8.80);
                    } 
                    else if (units <= 800) 
                    {
                        billAmount = (300 * 4.95) + (100 * 6.65) + (100 * 8.80) + ((units - 600) * 9.95);
                    } 
                    else if (units <= 1000) 
                    {
                        billAmount = (300 * 4.95) + (100 * 6.65) + (100 * 8.80) + (200 * 9.95) + ((units - 800) * 11.05);
                    } 
                    else 
                    {
                        billAmount = (300 * 4.95) + (100 * 6.65) + (100 * 8.80) + (200 * 9.95) + (200 * 11.05) + ((units - 1000) * 12.15);
                    }
                    break;
            }
            System.out.printf("Total Amount bill : " + billAmount);
            break;
		
	 case 2: 
         if (units <=100) 
         {
             billAmount = units * 6.65;
         } 
         else
         {
             billAmount = units * 10.45;
         }
         System.out.printf("Total Amount bill : " + billAmount);
         break;
        default :
        	System.out.print("invalid choice");
}
	}
}
