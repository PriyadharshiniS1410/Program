package Switchcase_2;
import java.util.Scanner;
public class Vehicle {

	public static void main(String[] args) {
	Scanner S= new Scanner(System.in);
	System.out.print("Enter the vehicle type ( Bike, Auto, car, Truck, Lorry) : ");
    String vehicle = S.nextLine();
    switch (vehicle) {
    case "Bike": 
    	System.out.print("Two wheeler_ Travel two Passenger- for both personal and commercial use");	
    	break;
    case "Auto": 
    	System.out.print("Three wheeler_ Travel maximum four Passenger- For commercial use");	
    	break;
    case "car": 
    	System.out.print("Four wheeler_ Travel five Passenger/ eight passenger- For both personal and commercial use");	
    	break;
    case "Truck": 
    	System.out.print("Four wheeler_ carry small number of goods- for commercial use");	
    	break;
    case "Lorry": 
    	System.out.print("four wheeler_carry large number of goods and products- for commercial use ");	
    	break;
    default:
    	System.out.print("invalid input, select the type from mentioned option");
    }
	}

}
