package Switchcase_2;

import java.util.Scanner;

public class Season {

	public static void main(String[] args) {
		Scanner S =new Scanner(System.in);
		System.out.print("Enter the number : ");
		int number= S.nextInt();
		switch (number) {
		case 1: System.out.print("January- Winter Season"); break;
		case 2: System.out.print("February"); break;
		case 3: System.out.print("March- Spring Season"); break;
		case 4: System.out.print("April- Spring Season"); break;
		case 5: System.out.print("May- Spring Season"); break;
		case 6: System.out.print("June- Summer Season"); break;
		case 7: System.out.print("July- Summer Season"); break;
		case 8: System.out.print("August- Summer Season"); break;
		case 9: System.out.print("September- Autumn Season"); break;
		case 10: System.out.print("October- Autumn Season"); break;
		case 11: System.out.print("November- Winter Season"); break;
		case 12: System.out.print("December- Winter Season"); break;
		default : System.out.print("Invalid input, select 1 to 12");
		}

	}

}
