package Switchcase_2;
import java.util.Scanner;
public class Vowels {

	public static void main(String[] args) {
		Scanner S= new Scanner(System.in);
		System.out.print("Enter the alphabets : ");
        char letter = S.next().charAt(0);
        switch (letter) {
        case 'A':
        case 'E':
        case 'I':
        case 'O':
        case 'U': 
        case 'a':
        case 'e':
        case 'i':
        case 'o':
        case 'u': 
        	System.out.print(letter + " is vowels");
        break;
        default : System.out.print(letter + " is consonant");
	}
	}
}
