import java.util.Scanner;
public class Triangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" Enter the side 1 = ");
double a = S.nextDouble();
System.out.print(" Enter the side 2 = ");
double b = S.nextDouble();
System.out.print(" Enter the side 3 = ");
double c = S.nextDouble();
if ((a+b>c) && (b+c>a) && (c+a>b)) {
	System.out.println(" Triangle is valid ");
}
else {
	System.out.println(" Triangle is not valid ");
}
	}

}
