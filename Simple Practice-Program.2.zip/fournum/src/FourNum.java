import java.util.Scanner;
public class FourNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" Enter the number 1 = ");
double a = S.nextDouble();
System.out.print(" Enter the number 2 = ");
double b = S.nextDouble();
System.out.print(" Enter the number 3 = ");
double c = S.nextDouble();
System.out.print(" Enter the number 4 = ");
double d = S.nextDouble();
double x = a + b + c + d;
System.out.println(" Enter the total of four number = " + x);
double z = (x/4);
System.out.println(" Enter the average of four number = " + z);
	}

}
