import java.util.Scanner;
public class Kelvin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" Enter the celsius value = ");
double x = S.nextDouble();
double z = x + 273.15;
System.out.println(" kelvin = " + z);
	}

}
