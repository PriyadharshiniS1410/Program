import java.util.Scanner;

public class Simple_Per {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sr = new Scanner(System.in);
		System.out.print("Enter the mark =");
		double mark = sr.nextDouble();
		System.out.print("Enter the Total =");
		double Total = sr.nextDouble();
		double percentage = (mark * 100) / Total;
		System.out.println("Simple percentage = " + percentage);

	}

}
