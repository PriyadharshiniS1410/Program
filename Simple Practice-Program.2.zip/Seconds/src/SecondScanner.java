import java.util.Scanner;
public class SecondScanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
System.out.print("Enter hours = ");
int hours = sc.nextInt();
int seconds = hours * 3600;
System.out.println(hours + "hours = " + seconds + "seconds");
	}

}
