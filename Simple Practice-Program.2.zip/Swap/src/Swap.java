import java.util.Scanner;
public class Swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" A = ");
int a = S.nextInt();
System.out.print(" B = ");
int b = S.nextInt();
int temp = a;
a = b;
b = temp;
System.out.println("After swapping");
System.out.println(" A = " + a);
System.out.println(" B = " + b);
	}

}
