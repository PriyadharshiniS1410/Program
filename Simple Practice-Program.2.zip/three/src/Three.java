import java.util.Scanner;
public class Three {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" Enter the number 1 = ");
int x = S.nextInt();
System.out.print(" Enter the number 2 = ");
int y = S.nextInt();
System.out.print(" Enter the number 3 = ");
int z = S.nextInt();
int q = x + y + z;
double a = q/3;
System.out.println(" sum of three numbers = " + q);
System.out.println(" Average of three number =" + a);
	}

}
