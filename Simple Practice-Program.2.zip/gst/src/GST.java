import java.util.Scanner;
public class GST {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" Enter the price amount = ");
double x = S.nextDouble();
System.out.print(" Enter the GST rate = ");
double y = S.nextDouble();
double z = (x+y)/100;
double q = x+z;
System.out.println(" GST = " + z);
System.out.println(" Total bill amout = " + q);
	}

}
