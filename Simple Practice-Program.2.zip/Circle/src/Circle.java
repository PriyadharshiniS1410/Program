import java.util.Scanner;
public class Circle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" Enter the radius of circle = ");
double a = S.nextDouble();
double x = Math.PI * a * a;
System.out.println(" Area of circle = " + x);
	}

}
