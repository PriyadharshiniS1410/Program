import java.util.Scanner;
public class Km {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner km = new Scanner(System.in);
System.out.print("Enter the kilometer = ");
double k = km.nextDouble();
double Miles = k * 0.621371;
System.out.println("value of miles = " + Miles + "m");
	}

}
