import java.util.Scanner;
public class Min {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print("Enter the minutes = ");
double x = S.nextDouble();
double z = x/60.0;
System.out.println(z + " hours is equal to " + x + " Minutes ");
	}

}
