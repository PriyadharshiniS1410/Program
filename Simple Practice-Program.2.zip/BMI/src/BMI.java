import java.util.Scanner;
public class BMI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" Enter height = ");
double x = S.nextDouble();
System.out.print(" Enter weight = ");
double y = S.nextDouble();
double z = y/(x*x);
System.out.println(" BMI value is = " + z);
	}

}
