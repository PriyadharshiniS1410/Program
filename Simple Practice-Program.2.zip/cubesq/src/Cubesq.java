import java.util.Scanner;
public class Cubesq {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s = new Scanner(System.in);
System.out.print("Enter square value = ");
int x = s.nextInt();
System.out.print("Enter rectangle value = ");
int y = s.nextInt();
int square = x * x;
int Rectangle = y * y * y;
System.out.println("Enter number of square = " + square);
System.out.println("Enter number of Rectangle = " + Rectangle);
	}

}
