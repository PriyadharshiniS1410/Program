package Nested_if;
import java.util.Scanner;
public class Login {

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		String username = "Anu";
		int Password = 123456;
System.out.print("Enter the user name : ");
String name = S.nextLine();
System.out.print("Enter the password : ");
int pass = S.nextInt();
if ( username.equals(name)) {
	if ( Password == pass) {
		System.out.print("Login successfully");
	}
	else {
		System.out.print("Password is incorrect");
	}
}
	else {
		System.out.print("Username and password are invalid");
	}
}
	}


