package Nested_if;
import java.util.Scanner;
public class Positive_Even {

	public static void main(String[] args) {
	Scanner S = new Scanner(System.in);
    System.out.print("Enter the number : ");
    int num = S.nextInt ();
    if (num>0) {
    	System.out.println(num + " is positive number");
    if (num %2 ==0) {
    System.out.print(num + " is even number");	
    }
    }
    else if (num %2 !=0) {
    	System.out.print(num + " is odd number");
    }
    else if (num<0) {
    	System.out.print(num + " is negative number");
    }
    else  {
    	System.out.print("number is zero");
    }
    
    
	}

}
