package Nested_if;
import java.util.Scanner;
public class Pass_fail {

	public static void main(String[] args) {
	Scanner S = new Scanner(System.in);
	int passmark= 40;
	System.out.print("Enter subject 1 mark : ");
    int sub1 = S.nextInt();
    System.out.print("Enter subject 2 mark : ");
    int sub2 = S.nextInt();
    if (sub1>=40) {
    	if (sub2>=40) {
    		System.out.print("Passed in both subject");
    }
    	else {
    		System.out.print("failed in subject 2");
    	}
    }
    	else {
    		System.out.print("failed in both subject");
    	}
    }
	}


