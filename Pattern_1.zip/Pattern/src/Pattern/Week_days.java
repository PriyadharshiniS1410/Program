package Pattern;

public class Week_days {

	public static void main(String[] args) {
	for (int i=1;i<=5;i++)
	{
		System.out.println(" week " + i);
	
		for (int j=1;j<=7;j++)
		{
			
			System.out.println(" Day " + j);
		}
	}
	}

}
