package Pattern;

public class Table_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x =2;
for (int i=1;i<=3;i++) {
	for (int j=1;j<=3;j++) { 
	System.out.print(x + "\t");	
	x += 2;
	}
	System.out.println("");
}
	}

}
