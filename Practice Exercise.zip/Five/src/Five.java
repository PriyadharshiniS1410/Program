import java.util.Scanner;

public class Five {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner S = new Scanner(System.in);
		System.out.print(" Enter the number 1 = ");
		int x = S.nextInt();
		System.out.print(" Enter the number 2 = ");
		int y = S.nextInt();
		System.out.print(" Enter the number 3 = ");
		int z = S.nextInt();
		System.out.print(" Enter the number 4 = ");
		int q = S.nextInt();
		System.out.print(" Enter the number 5 = ");
		int u = S.nextInt();
		int v = x + y + z + q + u;
		double a = v/5;
		System.out.println(" sum of five numbers = " + v);
		System.out.println(" Average of five number =" + a);

	}

}
