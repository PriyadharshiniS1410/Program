import java.util.Scanner;

public class Mark {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner S = new Scanner(System.in);
		System.out.print(" Student Name = ");
		String x = S.nextLine();
		System.out.print(" Student mark = ");
		int y = S.nextInt();
		System.out.println(" Results ");
		System.out.println(" Name : " + x);
		System.out.println(" Mark : " + y);


	}

}
