import java.util.Scanner;
public class Largest_three {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" Enter the number 1 = ");
double x = S.nextDouble();
System.out.print(" Enter the number 2 = ");
double y = S.nextDouble();
System.out.print(" Enter the number 3 = ");
double z = S.nextDouble();
if ((x>y) && (x>z)) {
	System.out.println(" largest of three number is = " + x);	
}
else if ((y>x) && (y>z)) {
	System.out.println(" largest of three number is = " + y);	
}
else {
	System.out.println(" largest of three number is = " + z);	
}
	}

}
