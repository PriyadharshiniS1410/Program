import java.util. Scanner;
public class Ascii {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" Enter the ASCII value = ");
char C = S.next().charAt(0);
int x = (int) C;
System.out.println(" Convert ASCII value to value = " + x);
	}

}
