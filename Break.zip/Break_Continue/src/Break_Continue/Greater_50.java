package Break_Continue;

public class Greater_50 {

	public static void main(String[] args) {
		int sum = 0;
        int number = 1;
        System.out.println("Printing numbers until the sum exceeds 50:");
        while (true) {
            sum += number;
            if (sum > 50) {
                System.out.println("\nSum is " + sum + " (Greater than 50). Stop");
                break; 
            }
            System.out.print(number + " ");
            number++;
        }

	}

}
