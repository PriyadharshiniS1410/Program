package Break_Continue;

public class Mul_5 
{
	public static void main(String[] args) {
int number = 5;
for (int i = 1; i <= 10; i++) {
            int product = number * i;
            if (product > 30) 
            {
                break;
            }
            System.out.println(number + " * " + i + " = " + product);
        }
	}
}
