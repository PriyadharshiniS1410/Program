package Break_Continue;

public class Divisible_7 {

	public static void main(String[] args) {
		for (int i = 1; i <= 100; i++) 
		{
            if (i % 7 == 0) {
                System.out.println("The first number divisible by 7 is: " + i);
                break; 
            }
        }

	}

}
