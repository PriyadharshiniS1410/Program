package Enhanced_forloop;

public class Print_number {

	public static void main(String[] args) {
		int[] number = {1,2,3,4,5};
		for (int num : number)
		{
			System.out.println(num);
	}
	}

}
