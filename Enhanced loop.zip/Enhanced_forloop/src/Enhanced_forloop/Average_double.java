package Enhanced_forloop;

public class Average_double {

	public static void main(String[] args) {
		double[] number = {2.2,3.7,4.1,7.8};
		double sum = 0;
		for (double num : number)
		{
			sum += num;
	   }
		System.out.println("Sum of double array : " + sum);
		double avg = sum/number.length;
		System.out.println("Average of double array : " + avg);

	}

}
