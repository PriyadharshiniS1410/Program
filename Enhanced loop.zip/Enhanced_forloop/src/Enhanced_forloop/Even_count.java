package Enhanced_forloop;

public class Even_count {

	public static void main(String[] args) {
		int[] number = {23,45,66,89,17};
		int count = 0;
		for (int num : number)
		{
			if (num%2==0) {
				count++;
		}
	}
System.out.print("Total number of even numbers: " + count);
}
}