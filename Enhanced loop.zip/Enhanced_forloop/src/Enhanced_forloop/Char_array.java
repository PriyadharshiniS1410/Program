package Enhanced_forloop;

public class Char_array {

	public static void main(String[] args) {
		char[] vowels = {'a','e','i','o','u'};
		for (char v : vowels)
		{
			System.out.println("Character of vowels: " + v);
	    }
	}

}
