package Enhanced_forloop;

public class Concatenate {

	public static void main(String[] args) {
		String[] Word = {"Java", " is", " platform", " independent"};
	
		for (String S : Word) {
			System.out.print(S);
		}


	}

}
