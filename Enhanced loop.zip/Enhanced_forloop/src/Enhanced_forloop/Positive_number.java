package Enhanced_forloop;

public class Positive_number {

	public static void main(String[] args) {
		int[] number = {1,-2,3,4,-5};
		for (int num : number)
		{
			if (num>0) 
			{
			System.out.println(num);
	        }
		}
	}
}
