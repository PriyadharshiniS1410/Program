package Enhanced_forloop;

public class Sum 
{

	public static void main(String[] args) 
	{
		int[] number = {1,2,3,4,5};
		int sum = 0;
		for (int num : number)
		{
			sum += num;
	    }
		System.out.println("Sum of elements of array : " + sum);
	}

}
