package Enhanced_forloop;

public class greater {

	public static void main(String[] args) {
		int[] number = {11,31,47,79,69};
		int max = number[0];
for (int num:number) 
{
	if (num>max)
	{
		max=num;
	}
}
System.out.print("The largest element of array is : " + max);
	}

}
