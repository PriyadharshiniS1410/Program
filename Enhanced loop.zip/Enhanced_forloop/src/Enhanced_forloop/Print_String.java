package Enhanced_forloop;

public class Print_String {

	public static void main(String[] args) {
		String[] Word = {"hello", " world"};
		System.out.print("Elements in the string array : ");
		for (String S : Word) {
			System.out.print("Elements in the string array : " + S);
		}

	}

}
