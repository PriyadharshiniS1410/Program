/**
 * 
 */

/**
 * 
 */
public class Add {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int number1 = 2;
int number2 = 3;
int sum = number1 + number2;
System.out.println("value of two number = " +sum);
	}

}
