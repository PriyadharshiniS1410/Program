
public class Simple {

}
