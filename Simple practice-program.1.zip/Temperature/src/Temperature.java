
public class Temperature {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double c = 32.1;
double f = (c * 1.8) + 32;
System.out.println("Celsius = " + c);
System.out.println("convert from celsius to fahrenheit = " + f);
	}

}
