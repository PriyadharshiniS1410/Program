
public class Square {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a = 25;
int perimeter = 4 * a;
System.out.println("Lenght of square = " + a);
System.out.println("Perimeter of square = " + perimeter);
	}

}
