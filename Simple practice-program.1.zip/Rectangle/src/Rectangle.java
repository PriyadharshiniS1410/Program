
public class Rectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
float length = 5.2f;
float width = 8.7f;
float area = length * width;
System.out.println("The length of rectangle = " +length + "cm");
System.out.println("The width of rectangle = " +width + "cm");
System.out.println("Area of rectangle = " +area + "cm^2");
	}

}
