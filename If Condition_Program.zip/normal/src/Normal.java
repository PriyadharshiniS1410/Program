import java.util.Scanner;
public class Normal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print("Enter the temperature value =");
double x = S.nextDouble();

if (x > 92) {
	System.out.println(x + " temperature is above normal");
}
	}

}
