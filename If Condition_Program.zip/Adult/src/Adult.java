import java.util.Scanner;
public class Adult {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print("Enter the person age = ");
int age = S.nextInt();
if(age>18) {
	System.out.println(" the person is adult ");
}
	}

}
