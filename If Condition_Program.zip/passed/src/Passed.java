import java.util.Scanner;
public class Passed {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print("Enter the student mark= ");
int x = S.nextInt();
if (x>=35) {
	System.out.println(x + " pass ");
}
	}

}
