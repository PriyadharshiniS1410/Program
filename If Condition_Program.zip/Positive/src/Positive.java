import java.util.Scanner;
public class Positive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner S = new Scanner(System.in);
System.out.print("Enter the value = ");		
int a = S.nextInt();

if (a>0)
{
	System.out.println(a + " is positive number ");
}
	}

}
