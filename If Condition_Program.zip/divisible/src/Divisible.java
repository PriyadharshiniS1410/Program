import java.util.Scanner;
public class Divisible {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print("Enter the value = ");
double x = S.nextDouble();
double result = (x % 5);
if (result == 0) {
	System.out.println(result + " is divisible by 5 ");
}

	}

}
