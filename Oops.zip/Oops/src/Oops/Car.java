package Oops;
class Cars {
String name;
String model;
double price;
void setdetails (String n,String m,double p) {
	name = n;
	model = m;
	price = p;
}
void display() {
	System.out.println(" customer ordered " + name + " " + model + " series " + " the price amount is " + price + " lakh");
}
}
public class Car {

	public static void main(String[] args) {
		Cars c1 = new Cars();
		Cars c2 = new Cars();
		Cars c3 = new Cars();
        c1.setdetails("Audi","Afour",44.8);
        c2.setdetails("BMW","WWseries",90.99);
        c3.setdetails("Benz","qyseries",89.78);
        c1.display();
        c2.display();
        c3.display();
	}

}
