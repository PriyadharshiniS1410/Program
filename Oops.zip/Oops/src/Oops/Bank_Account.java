package Oops;
class Bank {
String name;
String Bank_name;
int Account_number;
int Amount;
int currentdeposit;
int currentwithdraw;
void setinput(int deposit, int withdraw) {
	currentdeposit = deposit + Amount;
	currentwithdraw = withdraw + currentdeposit;
	
}
void display () {
	System.out.println("Account holder name : " + name);
	System.out.println("Bank name : " + Bank_name);
	System.out.println("Account Number : " + Account_number);
	System.out.println("Amount : " + Amount);
	System.out.println("After cash deposited : " + currentdeposit);
	System.out.println("After cash withdrawed : " + currentwithdraw);
}
}
public class Bank_Account {

	public static void main(String[] args) {
		Bank b1 = new Bank();
		b1.name = "riya";
		b1.Bank_name = "SBI";
		b1.Account_number = 1234567890;
		b1.Amount = 12500;
		b1.setinput(2500, 3400);
		b1.display();
		

	}

}
