package Oops;
import java.util.Scanner;
class Employee {
	String name;
	int id;
	double salary;
	void getinputs() {
		Scanner S = new Scanner(System.in);
		System.out.print("Enter the Employee name ");
		name = S.nextLine();
		System.out.print("Enter the Employee id ");
		id = S.nextInt();
		System.out.print("Enter the Employee salary ");
		salary = S.nextDouble();		
	}
	void display() {
		System.out.println("Employee name " + name);
		System.out.println("Employee id " + id);
		System.out.println("Employee salary " + salary);
	}
}

public class Employee_details {

	public static void main(String[] args) {
		Employee E1 = new Employee();
		E1.getinputs();
		E1.display();

	}

}
