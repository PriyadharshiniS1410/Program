package Oops;
class Student {
	String name;
	int age;
	void setdetails(String n, int a) {
		name = n;
		age = a;
	}
	void display() {
		System.out.println(name + " age is " + age + " years");
	}
}
public class Students_data {

	public static void main(String[] args) {
		Student s1 = new Student();
		Student s2 = new Student();
		s1.setdetails("Riya", 27);
		s2.setdetails("Anu",26);
		s1.display();
		s2.display();
	}

}
