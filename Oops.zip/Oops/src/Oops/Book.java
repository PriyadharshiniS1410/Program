package Oops;
import java.util.Scanner;
class Books {
	String title;
	String author;
	String language;
	int price;
	void getinputs() {
		Scanner S = new Scanner(System.in);
		System.out.print("Enter the Book Title : ");
		title = S.nextLine();
		System.out.print("Enter the Author name : ");
		author = S.nextLine();
        System.out.print("Enter the language : ");
		language = S.nextLine();
		System.out.print("Enter the price : ");
		price = S.nextInt();		
	}
	void display() {
		System.out.println("Book Title : " + title);
		System.out.println("Author name : " + author);
		System.out.println("Language : " + language);
		System.out.println("Book price : " + price);
	}
}

public class Book {

	public static void main(String[] args) {
		Books b = new Books();
		b.getinputs();
		b.display();


	}

}
