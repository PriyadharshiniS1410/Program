package Pattern_2;

public class Square_star {

	public static void main(String[] args) {
	for (int i=1;i<=3;i++) {
		for (int j=1;j<=3;j++) {
			System.out.print(" * ");
		}
		System.out.println();
	}

	}

}
