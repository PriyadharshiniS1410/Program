package Pattern_2;
import java.util.Scanner;
public class Number_pyramid {

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		int n = S.nextInt();
	
		for(int i=1;i<=n;i++) {
			for (int j=1;j<=n-i;j++) {
				System.out.print(" ");
			}
			for (int k=1;k<=i;k++) {
				System.out.print(k + " ");
			}
			System.out.println(" ");
		}

	}

}
