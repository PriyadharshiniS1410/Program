package Super_final_Instance;
import java.util.Scanner;
public class Final_Interest {

	public static void main(String[] args) {
		final double R = 34.5;
		double P;
		double N;
		System.out.println("Enter the interest rate : " + R + "%");
		Scanner S = new Scanner(System.in);
		System.out.print("Enter the Principle Amount : ");
		P= S.nextDouble();
		System.out.print("Enter the years : ");
		N= S.nextDouble();
double totalInterest= P * N * R;
double totalAmount= P + totalInterest;
System.out.println("Total Interest = " + totalInterest);
System.out.println("Total Amount = " + totalAmount);
	}

}
