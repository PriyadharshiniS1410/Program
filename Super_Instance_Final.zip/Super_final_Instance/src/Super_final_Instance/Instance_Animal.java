package Super_final_Instance;
interface Animals
{
	void sound();
}
class Dog implements Animals
{
	public void sound()
	{
		System.out.print(" Dog barks");
	}
}
public class Instance_Animal {

	public static void main(String[] args) {
		Animals A = new Dog();
		if (A instanceof Dog)
		{
			System.out.print("Dog is instance of Animal");
		}
		else {
			System.out.print("Dog is not instance of Animal");
		}
	}

}
