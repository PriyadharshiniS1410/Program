package Super_final_Instance;
import java.util.Scanner;
class Zoo
{
String name;
void Zooinput(Scanner S) 
{
	System.out.print("Enter the Zoo name : ");
	name=S.nextLine();
}
void displayZoo()
{
	System.out.println("Zoo name : " + name);
}
}
class Animal extends Zoo
{
	String name;
void Animalinput(Scanner S)
{
	System.out.print("Enter Animal name : ");
	this.name=S.nextLine();
}
void displayAnimal()
{
	System.out.println("Visitor looking for " + this.name);
	if (this.name.equals("Zebra") || this.name.equals("Elephant")){
		System.out.println(this.name + " available in " + super.name + " and You can visit ");
	}else {
		System.out.println(this.name + " not available in " + super.name );
	}
}
}

public class Super_Variable {

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		Zoo Z = new Zoo();
		Animal A = new Animal();
		A.Zooinput(S);
		A.Animalinput(S);
		System.out.println("Welcome to Zoo");
        A.displayZoo();
        A.displayAnimal();
	}

}
