package Super_final_Instance;
import java.util.Scanner;
class Vehicles
{
	String BrandName;
	String Manufacturer;
Vehicles ()
{
	BrandName="BMW";
}
void Vehiclesinput(Scanner S)
{
	System.out.print("Enter manufacturer Name : ");
	Manufacturer = S.nextLine();
}

void displayVehiclesinput()
         {
	      System.out.print("Brand : " + BrandName);
	      System.out.print("Manufacturer Name : " + Manufacturer);
         }
}
class Car extends Vehicles
{
	double Price;
	double Speed;
	String Model;
	String FuelType;
Car ()
{
	super();
}
void Carinput(Scanner S)
{
	super.Vehiclesinput(S);
	System.out.print("Enter model name : ");
	Model = S.nextLine();
	System.out.print("Enter the Price : ");
	Price = S.nextDouble();
	System.out.print("Enter Speed range : ");
	Speed = S.nextDouble();
	System.out.print("Enter the fuel type : ");
	FuelType = S.nextLine();
}
void displayCarinput()
{
	super.displayVehiclesinput();
	System.out.println("Model : " + Model);
	System.out.println("Price : " + Price);
	System.out.println("Speed Range : " + Speed);
	System.out.println("Fuel Type : " + FuelType);
	System.out.println("Thankyou for buying car from " + super.BrandName);
}
}
class Bike extends Vehicles
{
	String Model;
	String FuelType;
	double Price;
	double Speed;
Bike()
{
	super();
}
void Bikeinput(Scanner S)
{
	super.Vehiclesinput(S);
	System.out.print("Enter model name : ");
	Model = S.nextLine();
	System.out.print("Enter the Price : ");
	Price = S.nextDouble();
	System.out.print("Enter Speed range : ");
	Speed = S.nextDouble();
	System.out.print("Enter the fuel type : ");
	FuelType = S.nextLine();
}
void displayBikeinput()
{
	super.displayVehiclesinput();
	System.out.println("Model : " + Model);
	System.out.println("Price : " + Price);
	System.out.println("Speed Range : " + Speed);
	System.out.println("Fuel Type : " + FuelType);
	System.out.println("Thankyou for buying bike from " + super.BrandName);
}
}

public class Vehicle {

	public static void main(String[] args) {
	Scanner S = new Scanner(System.in);
		System.out.println("---- Car Details -----");
		Car C = new Car();
		C.Carinput(S);
		System.out.println("----- Bike Details ----");
		Bike B = new Bike();
		B.Bikeinput(S);
		System.out.println("---- Displaying Car Details -----");
	    C.displayCarinput();
		System.out.println("----- Displaying Bike Details ----");
		B.displayBikeinput();

	}

}
