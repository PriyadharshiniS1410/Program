package Super_final_Instance;
class Person
{
	String name="Anu";
void persondisplay()
{
	System.out.println("Student name : " + name);
}
}
class Student extends Person
{
	int id = 133;
	int Age=12;
void displayStudent()
{
	super.persondisplay();
	System.out.println("Student id : " + id);
	System.out.println("Age : " + Age);
}
}

public class Super_Methods {

	public static void main(String[] args) {
		Student S= new Student();
		S.displayStudent();

	}

}
