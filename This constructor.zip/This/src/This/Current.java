package This;

public class Current {
	public void sayHello() {
        System.out.println("Hello!");
    }
	 public void trigger() {
	        this.sayHello(); 
	    }

	public static void main(String[] args) {
		 Current program = new Current();
	        program.trigger();
	  

	}

}
