package This;

public class Book {
	String bookname;
	String authorname;
	int price;
	String lang;
	Book()
	{
		bookname="I too had a love story";
		authorname="Ravinder singh";
		price=350;
		lang="Eng/Hindi";
	}
	Book(String n,String a, int p, String l)
	{
		this.bookname=n;
		this.authorname=a;
		this.price=p;
		this.lang=l;
	}
	public static void main(String[] args) 
	{
		Book b1=new Book();
		Book b2=new Book("Two States", "Chetan Bhagat", 300, "English");
        System.out.println(b1.authorname + "'s " + b1.bookname + " available in " + b1.lang + " price is " + b1.price);
        System.out.println(b2.authorname + "'s " + b2.bookname + " available in " + b2.lang + " price is " + b2.price);
	}

}
