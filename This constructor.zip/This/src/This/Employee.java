package This;

public class Employee 
{
String name;
double salary;
Employee(String n, double s)
{
	this.name=n;
	this.salary=s;
}
	public static void main(String[] args) 
	{
		Employee e=new Employee("Anu", 59000);
        System.out.print("Employee name is " + e.name + " and offered monthly salary is " + e.salary);
	}

}
