package This;

public class Laptop {
		String name;
		int cost;
		Laptop(){
		name="Wipro";
		cost=78000;
		}
		Laptop(String n, int c)
		{
			this.name=n;
			this.cost=c;
		}
		
	public static void main(String[] args) {
		Laptop l1=new Laptop();
		Laptop l2 = new Laptop("TCS", 89000);
		System.out.println(l1.name + " is giving laptop to their employee which cost is around " + l1.cost);
		System.out.println(l2.name + " is giving laptop to their employee which cost is around " + l2.cost);

	}

}
