package Constructor;

class Bank_Acc {
String Accholder;
int Accnum;
double balance;
Bank_Acc()
{
	Accholder="Anu";
	Accnum=123456789;
	balance=9878900;
}
void display()
{
	System.out.println("Welcome to SBI ");
	System.out.println("Account holder name : " + Accholder);
	System.out.println("Account Number : " + Accnum);
	System.out.println("Available Balance in account : " + balance);
}
	public static void main(String[] args)
	{
		Bank_Acc b1= new Bank_Acc();
        b1.display();
	}

}
