package Constructor;

class Laptop 
{
String name;
int cost;
Laptop(String n, int c)
{
	name=n;
	cost=c;
}
void display()
{
	System.out.print(name + " is giving laptop to their employee which cost is around " + cost);
}
	public static void main(String[] args) 
	{
		Laptop l = new Laptop("TCS", 89000);
		l.display();	

	}

}
