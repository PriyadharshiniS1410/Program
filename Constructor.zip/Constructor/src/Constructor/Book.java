package Constructor;

class Book {
String bookname;
String authorname;
int price;
String lang;
Book()
{
	bookname="I too had a love story";
	authorname="Ravinder singh";
	price=350;
	lang="Eng/Hindi";
}
	public static void main(String[] args)
	{
		Book b=new Book();
		System.out.println("Book Title : "+ b.bookname);
		System.out.println("Author Name : "+ b.authorname);
		System.out.println("Book price : "+ b.price);
		System.out.println("Language Availability : "+ b.lang);
	}

}
