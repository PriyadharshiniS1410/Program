package Constructor;

class Car 
{
String name;
int model;
double price;
Car(String n, int m, double p)
{
	name = n;
	model = m;
	price = p;
}	
	public static void main(String[] args) 
	{
		Car c = new Car("BMW", 127, 2567890);
		System.out.print("car name is " + c.name + " model is " + c.model + " price is " + c.price);

	}
}

