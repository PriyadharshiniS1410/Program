package Constructor;

class Student {
String name;
int rollnum;
double mark;
Student( String n, int r, double m)
{
	name=n;
	rollnum=r;
	mark=m;
}
	public static void main(String[] args) 
	{
		Student S = new Student("Anu", 23, 78);
		System.out.print(S.name + " roll number " + S.rollnum + " getting " + S.mark + " mark");
	}

}
