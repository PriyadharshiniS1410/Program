package Else_if_ladder;
import java.util.Scanner;
public class Largest_three {

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		System.out.print("Enter the number 1 : ");
		int num1 = S.nextInt();
		System.out.print("Enter the number 2 : ");
		int num2 = S.nextInt();
		System.out.print("Enter the number 3 : ");
		int num3 = S.nextInt();
if (num1==num2 || num2==num3 || num3==num1) {
	System.out.print("invalid input- enter different number");
}
else if (num1>num2) {
	System.out.print(num1 + " is greatest of three number");
}
else if (num2>num3) {
	System.out.print(num2 + " is greatest of three number");
}
else if (num3>num1) {
	System.out.print(num3 + " is greatest of three number");
}

	}

}
