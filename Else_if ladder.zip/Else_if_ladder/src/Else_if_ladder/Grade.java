package Else_if_ladder;
import java.util.Scanner;
public class Grade {

	public static void main(String[] args) {

		Scanner S = new Scanner(System.in);
		System.out.print("Enter the name : ");
		String name = S.nextLine();
		System.out.print("Enter the mark (0-100) : ");
		int mark = S.nextInt();
if (mark > 100 || mark <0 ) {
	System.out.print("invalid input"); 
	}
	else if (mark >=90)	{
		System.out.print("Grade A- performance is outstanding");	
	}
	else if (mark >=80)	{
		System.out.print("Grade B- performance is good");	
	}
	else if (mark >=70)	{
		System.out.print("Grade C- performance is Average");	
	}
	else if (mark >=60)	{
		System.out.print("Grade D- performance is below average");	
	}
	else if (mark >=50)	{
		System.out.print("Grade E- performance is not satisfied");	
	}
	else if (mark < 50)	{
		System.out.print("Grade F (fail)- performance is poor");	
	}
	}

}  
