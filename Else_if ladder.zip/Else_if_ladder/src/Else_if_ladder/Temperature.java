package Else_if_ladder;

import java.util.Scanner;

public class Temperature {

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		System.out.print("Enter the today's temperature : ");
		int tem = S.nextInt();
		if (tem<=0) {
	System.out.print("Alert: Freezing outside");
}
else if (tem<=10) {
	System.out.print("today weather is cold");
}
else if (tem<=30) {
	System.out.print("today weather ic normal");
}
else if (tem>=31) {
	System.out.print(" is greatest of three number");
}

	}

}

