package Else_if_ladder;
import java.util.Scanner;
public class Traffic_light {

	public static void main(String[] args) {
	Scanner S = new Scanner(System.in);	
    System.out.print("Enter the (1 for red, 2 for orange, 3 for green) number : ");
    int color = S.nextInt();
    if (color == 1) {
    System.out.print(" RED signal - Stop");
	}
    else if (color ==2) {
    	System.out.print(" ORANGE signal - Prepare to stop/ Slow down");	
    }
    else if (color ==3) {
    	System.out.print(" GREEN signal - GO");	
    }
    else {
    	System.out.print("Invalid input enter the number between 1 to 3");	
    }
}
}