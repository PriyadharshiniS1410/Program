package Switch_case;
import java.util.Scanner;
public class Day_week {

	public static void main(String[] args) {
		Scanner S =new Scanner(System.in);
		System.out.print("Enter the day : ");
		int day= S.nextInt();
		switch (day) {
		case 1: System.out.print("monday"); break;
		case 2: System.out.print("Tuesday"); break;
		case 3: System.out.print("Wednesday"); break;
		case 4: System.out.print("Thursday"); break;
		case 5: System.out.print("Friday"); break;
		case 6: System.out.print("Saturday"); break;
		case 7: System.out.print("Sunday"); break;
		default : System.out.print("Invalid input, select 1 to 7");
		}

	}

}
