package Switch_case;
import java.util.Scanner;
public class Grade {

	public static void main(String[] args) {
	  Scanner S = new Scanner(System.in);
	  System.out.print("Enter the mark ( 1 to 100) : ");
      int mark = S.nextInt();
      if (mark >100 || mark<0) {
    	 System.out.print("invalid input select 1 to 100"); 
      } else {
    	  int result = mark / 10;
      switch (result) {
      case 10 : System.out.print("Grade U"); break;
      case 9 : System.out.print("Grade A"); break;
      case 8 : System.out.print("Grade B"); break;
      case 7 : System.out.print("Grade C"); break;
      case 6 : System.out.print("Grade D"); break;
      case 5 : System.out.print("Grade E"); break;
      default : System.out.print("Grade F"); 
      }
      
	}

}
}
