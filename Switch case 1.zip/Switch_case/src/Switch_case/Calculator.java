package Switch_case;
import java.util.Scanner;
public class Calculator {

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		int num1;
		int num2;
		int operator;
		System.out.print("Enter the operator( 1 for sum, 2 for Sub, 3 for mul, 4 for div) : ");
		operator = S.nextInt();
		System.out.print("Enter the number 1 value : ");
		num1 = S.nextInt();
		System.out.print("Enter the number 2 value : ");
		num2 = S.nextInt();
		switch (operator) {
			case 1:
				int sum = num1 + num2;
				System.out.print("Addition of two number : " + sum);
				break;
			case 2:
				int sub = num1 - num2;
				System.out.print("Subraction of two number : " + sub);
				break;		
			case 3:
				int multiply = num1 * num2;
				System.out.print("Multiplication of two number : " + multiply);
				break;
			case 4:
				if (num2 !=0) {
				int result = num1 / num2; 
				System.out.print("Division of two number : " + result); }
				else {
					System.out.print("Division ny zero not allowed");
				}
				break;
			default :
				System.out.print("Invalid input, Select between 1 to 4");
				break;
		}
	}

}
