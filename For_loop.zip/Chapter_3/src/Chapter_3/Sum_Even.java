package Chapter_3;

public class Sum_Even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int esum = 0;
		int osum = 0;
for (int i=1;i<=20;i++) {
	if (i%2==0) {
		esum+=i;	
}
	else {
		osum+=i;
	}
}
	System.out.println("sum of Even number = " + esum);
		System.out.println("sum of odd number = " + osum);
	}
}
	

