package Chapter_3;
import java.util.Scanner;
public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner S = new Scanner(System.in);
		System.out.print(" Enter the value = ");
		int x = S.nextInt();
	    long f = 1;
					for (int i =1;i<=x;i++) {
						f *= i;
					}	
System.out.println(" Factorial of " + x + " is " + f);
	}
	}

