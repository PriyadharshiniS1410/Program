package Chapter_3;

public class Table_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i = 1;i<=10;i++) {
               System.out.println("5 *" + i + " = " + 5*i);
	}

}
}
