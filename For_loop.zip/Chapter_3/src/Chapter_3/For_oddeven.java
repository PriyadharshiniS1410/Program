package Chapter_3;

public class For_oddeven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
for (int i=1;i<=20;i++) {
	if (i %2 == 0) {
		System.out.println(" Even number " +i);
	}
	else
		System.out.println(i + " Odd number ");
}

	}

}
