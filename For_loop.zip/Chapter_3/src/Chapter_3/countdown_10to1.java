package Chapter_3;

public class countdown_10to1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
for (int i=10;i>=1;i--) {
	System.out.println(" Enter the value = " +i);
}
	}

}
