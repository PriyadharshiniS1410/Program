package Chapter_3;

public class Reverse_string {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String x = "Good";
String y = "";
for (int i=x.length()-1;i>=0;i--) {
	y += x.charAt(i);
}
System.out.println(" Enter the reversed string = " + y);
	}

}
