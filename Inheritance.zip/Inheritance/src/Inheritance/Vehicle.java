package Inheritance;
import java.util.Scanner;
class Vehicles
{
	String BrandName;
	String Manufacturer;
void Vehiclesinput(Scanner S)
{
	System.out.print("Enter brand name : ");
	this.BrandName = S.nextLine();
	System.out.print("Enter manufacturer Name : ");
	this.Manufacturer = S.nextLine();
}

void displayVehiclesinput()
         {
	      System.out.print("Brand : " + BrandName);
         }
}
class Car extends Vehicles
{
	double Price;
	double Speed;
	String Model;
	String FuelType;
void Carinput(Scanner S)
{
	super.Vehiclesinput(S);
	System.out.print("Enter model name : ");
	this.Model = S.nextLine();
	System.out.print("Enter the Price : ");
	this.Price = S.nextDouble();
	System.out.print("Enter Speed range : ");
	this.Speed = S.nextDouble();
	System.out.print("Enter the fuel type : ");
	this.FuelType = S.nextLine();
}
void displayCarinput()
{
	super.displayVehiclesinput();
	System.out.println("Model : " + Model);
	System.out.println("Price : " + Price);
	System.out.println("Speed Range : " + Speed);
	System.out.println("Fuel Type : " + FuelType);
}
}
class Bike extends Vehicles
{
	String Model;
	String FuelType;
	double Price;
	double Speed;
void Bikeinput(Scanner S)
{
	super.Vehiclesinput(S);
	System.out.print("Enter model name : ");
	this.Model = S.nextLine();
	System.out.print("Enter the Price : ");
	this.Price = S.nextDouble();
	System.out.print("Enter Speed range : ");
	this.Speed = S.nextDouble();
	System.out.print("Enter the fuel type : ");
	this.FuelType = S.nextLine();
}
void displayBikeinput()
{
	super.displayVehiclesinput();
	System.out.println("Model : " + Model);
	System.out.println("Price : " + Price);
	System.out.println("Speed Range : " + Speed);
	System.out.println("Fuel Type : " + FuelType);
}
}
public class Vehicle {

	public static void main(String[] args) 
	{
		Scanner S = new Scanner(System.in);
		System.out.println("---- Car Details -----");
		Car C = new Car();
		C.Carinput(S);
		System.out.println("----- Bike Details ----");
		Bike B = new Bike();
		B.Bikeinput(S);
		System.out.println("---- Displaying Car Details -----");
	    C.displayCarinput();
		System.out.println("----- Displaying Bike Details ----");
		B.displayBikeinput();
	}
}
