package Inheritance;
import java.util.Scanner;
class Person
{
	String name;
	int age;
void Personinput(Scanner S)
{
	System.out.print("Enter name : ");
	this.name=S.nextLine();
	System.out.print("Enter age : ");
	this.age=S.nextInt();
}
void displayPerson()
{
	System.out.println("Name : " + name);
	System.out.println("Age : " + age);
}
}
class Employee extends Person
{
	String Empid;
	double salary;
void Employeeinput(Scanner S)
{
	super.Personinput(S);
	S.nextLine();
	System.out.print("Enter Employee Id : ");
	Empid=S.nextLine();
	System.out.print("Enter Salary : ");
	salary=S.nextDouble();
}
void displayEmployee()
{
	displayPerson();
	System.out.println("Employee Id : " + Empid);
	System.out.println("Salary : " + salary);
}
}
class Manager extends Employee
{
	String dept;
	int teamsize;
void Managerinput(Scanner S)
{
	Employeeinput(S);
	S.nextLine();
	System.out.print("Enter department name : ");
	dept=S.nextLine();
	System.out.print("Enter team size : ");
	teamsize=S.nextInt();
}
void displayManager()
{
	displayEmployee();
	System.out.println("Department : " + dept);
	System.out.println("Team Size : " + teamsize);
}
}
public class Multilevel 
{
	public static void main(String[] args) 
	{
	    Scanner S = new Scanner(System.in);
        Manager M= new Manager();
        M.Managerinput(S);
        System.out.println("--------------------------------------");
        System.out.println("~~~~~~~ Worker Details ~~~~~~~~");
        M.displayManager();
       
	}
}
