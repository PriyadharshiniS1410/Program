/**
 * 
 */
/**
 * 
 */
module Inheritance {
}