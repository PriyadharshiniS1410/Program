package Do_While;
import java.util.Scanner;
public class Reverse_number {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();
        int originalNum = num; 
        int reversed = 0;
        do {
            int digit = num % 10;         
            reversed = reversed * 10 + digit; 
            num /= 10;                    
        } while (num != 0);            
        System.out.println("Original Number: " + originalNum);
        System.out.println("Reversed Number: " + reversed);
        

	}

}
