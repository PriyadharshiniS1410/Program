package Do_While;
import java.util.Scanner;
public class Factorial {

	public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a non-negative integer: ");
        int number = scanner.nextInt();
        if (number < 0) {
            System.out.println("Factorial is not defined for negative numbers.");
        } else {
            long factorial = 1; 
            int i = 1;          
            do {
                if (number == 0) {
                    break; 
                }
                factorial *= i;
                i++;
            } while (i <= number);
            
            System.out.println("The factorial of " + number + " is: " + factorial);
        }

	}

}
