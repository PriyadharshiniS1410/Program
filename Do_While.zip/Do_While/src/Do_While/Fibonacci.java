package Do_While;
import java.util.Scanner;
public class Fibonacci {

	public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of terms (n): ");
        int n = scanner.nextInt();
        if (n <= 0) {
            System.out.println("Please enter a positive integer greater than 0.");
        } else {
            int firstTerm = 0;
            int secondTerm = 1;
            int count = 1;
            System.out.print("Fibonacci Series up to " + n + " terms: ");
            do {
                System.out.print(firstTerm + " ");
                int nextTerm = firstTerm + secondTerm;
                firstTerm = secondTerm;
                secondTerm = nextTerm;
                count++;
            } while (count <= n);
            System.out.println(); 
            }

	}

}
