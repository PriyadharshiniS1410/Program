import java.util.Scanner;
public class Password {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String password = "secret";		
Scanner S = new Scanner(System.in);
System.out.print(" Enter the password = ");
String x = S.nextLine();
if (x == password) {
	System.out.println("Password is correct");
}
else if (x != password) {
	System.out.println("Password is incorrect");
}
	}

}
