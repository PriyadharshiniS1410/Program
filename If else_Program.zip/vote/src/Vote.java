import java.util.Scanner;
public class Vote {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print("Enter the age = ");
int x = S.nextInt();
if (x>18) {
	System.out.println("Eligible to vote");
}
else if (x<18) {
	System.out.println("Not eligible to vote");
}
	}

}
