import java.util.Scanner;
public class posneg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s = new Scanner(System.in);
System.out.print("Enter the number = ");
int x = s.nextInt();
if (x>=0) {
	System.out.println(x + " is positive number ");
}
else if (x<0) {
	System.out.println(x + " is negative number ");
}
	}

}
