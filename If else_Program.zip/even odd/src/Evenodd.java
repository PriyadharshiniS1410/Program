import java.util.Scanner;
public class Evenodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" Enter the number = ");
int x = S.nextInt();
int y = (x%2);
if (y ==0) {
	System.out.println(x + " is even number ");
}
else if (y != 0) {
	System.out.println(x + " is odd number ");	
}
	}

}
