import java.util.Scanner;
public class greater {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner S = new Scanner(System.in);
System.out.print(" Enter the number1 = ");
int x = S.nextInt();
System.out.print(" Enter the number2 = ");
int y = S.nextInt();
if (x>y) {
	System.out.println(x  + " is greater number ");
}
else if (y>x) {
	System.out.println(y  + " is greater number ");
}

	}

}
