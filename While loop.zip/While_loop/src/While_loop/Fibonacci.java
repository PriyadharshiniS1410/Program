package While_loop;
import java.util.Scanner;
public class Fibonacci {

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		System.out.print("Enter the count ");
		int n= S.nextInt();
int firstnum =0;
int Secondnum =1;
int i =1;
while (i<=n) {
	System.out.print(firstnum + ", ");
	int nextnum = firstnum + Secondnum;
	firstnum = Secondnum;
	Secondnum= nextnum;
	i++;
}
	}

}
