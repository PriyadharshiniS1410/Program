package While_loop;
import java.util.Scanner;
public class natural_numbar {

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		int n = S.nextInt();
System.out.println("Enter the value of natural number is " + n);
		int i =1;
		int sum = 0;
				while (i<=n) {
					sum +=i;
					i++;
				}
System.out.println("sum of natural number is " + sum);
	}

}
