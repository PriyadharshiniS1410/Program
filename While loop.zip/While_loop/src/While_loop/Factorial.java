package While_loop;
import java.util.Scanner;
public class Factorial {

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		System.out.print("Enter the number ");
		int num = S.nextInt();
		long factorial =1;
		int i = num;
		while (i>0) {
			factorial *= i;
			i--;
		}

System.out.println("Value of " + num + " factorial is " + factorial);
	}

}
