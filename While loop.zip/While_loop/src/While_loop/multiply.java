package While_loop;
import java.util.Scanner;
public class multiply {

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		int mul = S.nextInt();
System.out.println("Enter the multiplication table value " + mul);
int i = 1;
while(i<=10) {
	int x = i * mul;
	System.out.println("multiplcation of " + mul + " is " + x);
	i++;
	
}

	}

}
