package While_loop;

public class digit_count {

	public static void main(String[] args) {
		int num = 123456;
		int orgnum = num;
		int count = 0;
		if(num ==0) {
			count =1;
		}
		else {
			while (num !=0) {
				num = num / 10;
				count++;
			}
		}
			System.out.println("count is " + count);		
	}

}
