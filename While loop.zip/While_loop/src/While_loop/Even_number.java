package While_loop;

public class Even_number {

	public static void main(String[] args) {
		int i = 2;
		while (i<=10) {
			System.out.println(" Even number " + i);
			i += 2;
		}

	}

}
